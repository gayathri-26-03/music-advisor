package advisor;
import com.sun.net.httpserver.HttpExchange;
import com.sun.net.httpserver.HttpHandler;
import com.sun.net.httpserver.HttpServer;

import java.io.IOException;
import java.io.OutputStream;
import java.net.InetSocketAddress;
import java.net.URI;
import java.net.http.*;
import java.util.*;

public class Main {
    public static void main(String[] args) throws IOException, InterruptedException {
        Scanner scanner = new Scanner(System.in);
        String choice;
        String name;
        boolean flag = false;

        do {
            choice = scanner.next();

            switch (choice) {

                case "featured":

                    if (flag) {
                        featured();
                    } else {
                        System.out.println("Please, provide access for application.");
                    }
                    break;

                case "new":
                    if (flag) {
                        new1();
                    } else {
                        System.out.println("Please, provide access for application.");
                    }
                    break;

                case "categories":
                    if (flag) {
                        categories();
                    } else {
                        System.out.println("Please, provide access for application.");
                    }
                    break;

                case "playlists":
                    if (flag) {
                        name = scanner.next();
                        playlist(name);
                    } else {
                        System.out.println("Please, provide access for application.");
                    }

                    break;

                case "auth": flag = true;
                    HttpServer server = HttpServer.create();
                    final int[] code = new int[1];
                    server.bind(new InetSocketAddress(8080), 0);
                    server.createContext("/",
                            new HttpHandler() {
                                public void handle(HttpExchange exchange) throws IOException {
                                    String query = exchange.getRequestURI().getQuery();
                                    if (query.startsWith("code")) {
                                        String hello = "Got the code. Return back to your program.";
                                        code[0] = exchange.getResponseCode();
                                        exchange.sendResponseHeaders(200, hello.length());
                                        exchange.getResponseBody().write(hello.getBytes());
                                        exchange.getResponseBody().close();
                                    } else {
                                        String hello = "Authorization code not found. Try again.";
                                        exchange.sendResponseHeaders(200, hello.length());
                                        exchange.getResponseBody().write(hello.getBytes());
                                        exchange.getResponseBody().close();
                                    }
                                }
                            }
                    );
                    server.start();

                    System.out.println("use this link to request the access code:");
                    System.out.println("https://accounts.spotify.com/authorize?client_id=f674a9a4caaf4529bd4ec978d5a0dd5c&redirect_uri=http://localhost:8080&response_type=code");
                    System.out.println("waiting for code...");

                    HttpClient client = HttpClient.newBuilder().build();
                    HttpRequest request = HttpRequest.newBuilder()
                            .header("Content-Type", "application/x-www-form-urlencoded")
                            .header("grant_type","authorization_code")
                            .uri(URI.create("https://accounts.spotify.com/authorize?client_id=f674a9a4caaf4529bd4ec978d5a0dd5c&redirect_uri=http://localhost:8080&response_type=code"))
                            .POST(HttpRequest.BodyPublishers.ofString("login=admin&password=admin"))
                            .build();

                    try {
                        HttpResponse<String> response = client.send(request, HttpResponse.BodyHandlers.ofString());

                        if (response.statusCode() == 200) {
                            System.out.println("code received");
                            System.out.println(response.body());
                        }
                    } catch (Exception e) {
                        System.out.println("Exception: " + e);
                    }

                    server.stop(1);
                    System.out.println("making http request for access_token...");

                    try {
                        String plainCredentials = "f674a9a4caaf4529bd4ec978d5a0dd5c" + ":" + "ecb412e3114747aa9ae8dd4f656da541";
                        String base64Credentials = new String(Base64.getEncoder().encode(plainCredentials.getBytes()));

                        HttpRequest request1 = HttpRequest.newBuilder()
                                .header("Content-Type", "application/x-www-form-urlencoded")
                                .header("grant_type","authorization_code")
                                .header("Authorization", "Basic " + base64Credentials)
                                .uri(URI.create("https://accounts.spotify.com/api/token?code=" + code[0] + "&redirect_uri=http://localhost:8080"))
                                .POST(HttpRequest.BodyPublishers.ofString("login=admin&password=admin"))
                                .build();
                        HttpResponse<String> response1 = client.send(request1, HttpResponse.BodyHandlers.ofString());

                        //if (response1.statusCode() == 200) {
                            System.out.println(response1.body());
                        //}
                    } catch (Exception e) {
                        System.out.println(e);
                    }

                    //System.out.println("---SUCCESS---");
                    break;

                case "exit": System.out.println("---GOODBYE!---");
                    break;
            }
        } while(!choice.equals("exit"));

    }

    public static void featured(){
        System.out.println("---FEATURED---\n" +
                "Mellow Morning\n" +
                "Wake Up and Smell the Coffee\n" +
                "Monday Motivation\n" +
                "Songs to Sing in the Shower\n");
    }

    public static void new1() {
        System.out.println("---NEW RELEASES---\n" +
                "Mountains [Sia, Diplo, Labrinth]\n" +
                "Runaway [Lil Peep]\n" +
                "The Greatest Show [Panic! At The Disco]\n" +
                "All Out Life [Slipknot]\n");
    }

    public static void categories(){
        System.out.println("---CATEGORIES---\n" +
                "Top Lists\n" +
                "Pop\n" +
                "Mood\n" +
                "Latin\n");
    }

    public static void playlist(String name) {
        System.out.println("---MOOD PLAYLISTS---\n" +
                "Walk Like A Badass  \n" +
                "Rage Beats  \n" +
                "Arab Mood Booster  \n" +
                "Sunday Stroll\n");
    }
}
